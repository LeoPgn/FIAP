package br.com.fiap.beans;

import br.com.fiap.beans.entities.Pessoa;

public class Main {
    public static void main(String[] args) {
        System.out.printf("Hello World!");

        var Pessoa = new Pessoa();

        }
    }