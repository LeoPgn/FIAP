package org.example.enums;

public enum PaymentMethodType {
    CREDIT_CARD,
    DEBIT_CARD,
    BILL,
    PIX,
}
