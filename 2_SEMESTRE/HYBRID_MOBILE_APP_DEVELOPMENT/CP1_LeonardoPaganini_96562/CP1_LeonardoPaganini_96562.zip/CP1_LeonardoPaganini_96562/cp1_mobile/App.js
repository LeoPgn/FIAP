import { View } from 'react-native';


import Instagram from './instagram/card';

export default function App() {
  return (
    <View>
      <Instagram/>
    </View>
  );
}